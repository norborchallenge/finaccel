Require
 - JDK 1.8
 - PostgreSQL

Setup
 - Please create dbuse=finaccel, database=finaccel and run scheama.sql before run
 - Copy your token into constant/Config.java in Test Packages.

Command
 - mvn clean install -DskipTests
 - mvn spring-boot:run

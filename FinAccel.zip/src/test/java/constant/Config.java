package constant;

/**
 *
 * @author nuboat
 */
public class Config {

	public static final String TOKEN_TEST = "PLEASE UPDATE CURRENT TOKEN FROM https://developers.facebook.com";

	private Config() {}

}

package finaccel.controller;

/**
 *
 * @author nuboat
 */
public class Routes {
	
	public static final String INDEX = "/";
	
	public static final String FBSIGNIN = "/fbsignin";
	
}
